                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1701246
Pyritohedron {104} Pyritohedron {102} Tetartohedron {214} by dpopcorn is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a 3D crystallographic model depicting the Tetartohedral class of the cubic system (23 point group). This means that there are two-fold and three-fold axes of symmetry with no mirror planes. 

Check out below to find out how I made this, and check out the MakerEd Project to make this and other cubic system solids! 

Note: This model needs extra work to be 3D printed. To print this model, do one of these things: add a resin base, make a very fine support structure, or split the model in half and add a chamfer to the edge resting on the print area.

# How I Designed This

This model was made with SolidWorks 2015. In this model, I cut the planes {104}, {102}, and {214} with only threefold and twofold axes of symmetry (no mirror planes). To learn more about plane notation (Miller indices) and symmetry in the cubic system, check out the MakerEd Project section.

It just so happens that the cubic system is a special case for the Miller indices: the numbers coincide with the normal vector to the plane! By drawing a line from the origin to one of the specified points (e.g. {1,0,4}), and selecting a point on the unit cube, a plane can be defined. I used the Surface Cut tool to cut the planes.



![Alt text](https://cdn.thingiverse.com/assets/db/0a/cc/54/b7/Maker_Ed_5.png)
Starting Cube.

![Alt text](https://cdn.thingiverse.com/assets/84/38/00/33/43/MakerEd_1.png)
Cube with one corner cut by 3 planes.

Next, I used the Move/Copy Body function to make superimposed copies of the rotated solid. This was followed by using the Intersect function to take only the inside solid.

![Alt text](https://cdn.thingiverse.com/assets/4e/54/44/a1/43/MakerEd_2.png)
The solid was rotated twice at 120 degrees on the point of the unit cube, and then the three solids were intersected.

It's just repeating the rotations after that, until you arrive at the solid.

![Alt text](https://cdn.thingiverse.com/assets/d4/78/6e/78/cc/MakerEd_4.png)
Final solid.

# Project: Make a Crystallographic Model

## Project Name: Tetartohedral Class Model


## Overview and Background

By completing this project, you should be able to make any 3D model of the cubic crystal system, given two parameters: specific planes of the faces (note: a form is a set of planes which are related by symmetry), and a class of symmetry.
Note: the primers may be confusing, but they explain how different models can be made. Even if you do not understand the details, you can still follow the project step-by-step. 

## Objectives

* Make planes based on a given notation.
* Cut a cube with given planes at a given location.
* Use symmetry elements (rotation and mirror functions), based on one of the classes of the cubic system, to reproduce planes (also known as forms).

## Audiences

* Due to the mathematical background of the project, this is recommended for high school students and older. However, younger students who grasp advanced 3D concepts are encouraged to try!
* Students who have taken classical mineralogy classes may find this project easier and more relevant to their field of study.
* Anyone who thinks symmetry is cool should try this out.

## Subjects

* Math (Vectors, Spatial Geometry)
* Science (Crystallography, Mineralogy)

## Skills Learned

* Defining Planes
* Rotating Features
* Intersecting Bodies

## Primer: Miller Indices

A Miller index is a notation that defines a set of parallel planes in 3D space. In the cubic system, {hkl} (a generalized Miller index) defines all planes that are parallel to the plane intersecting (1/h,0,0), (0,1/k,0) and (0,0,1/l).

For example, {111} is parallel to a plane that intersects the points (1,0,0), (0,1,0) and (0,0,1). Another example is {100}, which intersects the points (1,0,0), (0,1/0,0), (0,0,1/0) (i.e. it intersects the x-axis and is parallel to the y-axis and z-axis). 

It just so happens that in the cubic system, the Miller index is normal, or perpendicular, to that plane (you can prove this by evaluating the dot product of the vector defined by the Miller index with two vectors on the plane; if it is zero, then the vectors are perpendicular). Normal vectors are great because they are relatively easy to define in SolidWorks - just draw a line, and make a plane perpendicular to that line! For example, to define the {111}, draw a line from the origin to (1,1,1) and create a plane that is perpendicular to that line.

(Note: in other crystal systems, this is modified to {1/h, 0, 0}a, {0, 1/k, 0}b, {0, 0, 1/l}c since the unit axes  are not necessarily of equal length nor perpendicular. But this makes things massively complicated and no longer perpendicular, so we'll stick to cubic system.) 

You can read more about Miller Indices on [Wikipedia](https://en.wikipedia.org/wiki/Miller_index).

## Primer: Symmetry Elements

If you ever look at a cube (use a die as an example), you might notice that it's very symmetrical. First off, if we look at one of the square faces, we notice that if the square face is rotated (and also the cube), that square would look identical every 90 degrees, i.e. it would look exactly the same 4 times in a complete rotation. This is called a four-fold axis of symmetry, and there are 3 unique four-fold axes on a cube (think about looking down x, y, and z-axes).

![Alt text](https://cdn.thingiverse.com/assets/cd/92/32/78/a1/MakerEd_6.png)
Square face of a cube. Looks the same every 90 degrees.

Now, if we look down a cube's corner to the opposite corner, that's three-fold symmetry (there are four of them on a cube, reflective of the 8 edges). 


![Alt text](https://cdn.thingiverse.com/assets/d0/ab/8f/bd/d1/MakerEd_8_3-fold.png)
Three-fold symmetry at the corner of a cube.

And from an edge to an opposite edge, there's two-fold symmetry (there are 6 of them on a cube, reflective of the 12 edges). 

![Alt text](https://cdn.thingiverse.com/assets/ec/f4/b7/7c/92/MakerEd_7_2-fold.png)
Looking down an edge shows a two-fold symmetry.

But keep in mind that in more complicated solids, not all edges and corners exhibit symmetry in this way; the whole crystallographic model must look exactly the same when rotated a certain amount (60, 90. 120, or 180 degrees) at that orientation.

The other important type of symmetry is a mirror plane. Simply put, if you put a glass mirror through your solid and the image looks the same as the other side of the solid, you've got a mirror plane. 

The cubic system is defined as having 4 unique three-fold axes of symmetry. A lot of cubic crystals (including this Thing) lack the four-fold axes because they become two-fold axes (such as the Tetrahedron {111}, pictured below).

![Alt text](https://cdn.thingiverse.com/assets/9a/b1/5a/af/34/MakerEd_9_tetrahedron_in_cube.png)
ATetrahedron {111} fits in a Cube {100}. Notice how the cube's square sides, having four-fold symmetry, have become edges with two-fold symmetry in the tetrahedron (more specifically, this is a rotoinverted four-fold).

<iframe src="//www.youtube.com/embed/CCaX5eTteEg" frameborder="0" allowfullscreen></iframe>
Check out this cool animation of the rotational symmetry of an octahedron!

## Lesson: How to make a Crystallographic Model


## Step 1: Making the unit cube

Start by making a new Part file, and add a Coordinate System. In a 3D sketch, plot the points (2,2,2), (2,2,-2), (2,-2,2)...i.e.(+/-2,+/-2,+/-2) as well as (2,0,0), (0,2,0), (0,0,2), (2,2,0), (2,0,2), and (0,2,2). These are reference points to make the cube. Make sure that they are all fixed points!

Add an axis from the origin to (2,2,2). This is always a three-fold axis in the cubic system. Next, add a plane which is parallel to the Right Plane and intersects (2,0,0). This plane is {100}.

Now, sketching on {100}, connect the four corner points of the cube together. Click Planar Surface on the Surfaces toolbar to make the square a surface. 

To make the cube, we need to copy the square a couple of times. Locate the Move/Copy Body function (Insert>Features>Move/Copy...), and select the square. Check copy, make 2 copies, and rotate on the three-fold axis at 120 degrees.
 

![Alt text](https://cdn.thingiverse.com/assets/aa/2e/67/f1/31/MakerEd_15_rotations.png)
Rotating the square.

Do another Move/Copy, this time selecting the three faces and rotating about the origin, 90 degrees on the x-axis, and 180 degrees on the y-axis. This should cover the cube completely.

![Alt text](https://cdn.thingiverse.com/assets/96/f0/de/66/75/MakerEd_16_cube.png)
The completed cube.

On the Surfaces Toolbar, locate the Knit Surface tool to knit your cube together.

## Step 2: Make the planes

Start a 3D sketch, and plot fixed points (1,0,2), (1,0,4), and (2,1,4), as well as (2,-2,1.25). Next, draw three lines of infinite length through the origin and the first three points. Remember which line is which!

Now, save and exit the sketch, and make three reference planes. Since we have a perpendicular line and intersection point for each plane, leave the third reference blank.
* The {102} plane is perpendicular to the line intersecting (1,0,2) and intersects (2,-2,1.25). 
* The {104} is perpendicular to the line intersecting (1,0,4) and intersects (0,2,2). 
* Finally, the {214} is normal to its line and intersects (0,2,2). 

Be sure to label your planes or it will get hectic.



![Alt text](https://cdn.thingiverse.com/assets/0f/be/af/e4/7e/MakerEd_24_example_making_plane.png)
Example of making the {102} plane settings.

![Alt text](https://cdn.thingiverse.com/assets/37/58/0b/69/c1/MakerEd_17_planes.png)
Cube with three planes illustrated. Starting to look complicated.

## Step 3: Cut the cube

Click Insert>Cut>With Surface... and select {102}. Press the check mark. If the majority of the solid has disappeared, then right click SurfaceCut1 in the FeatureManager, click Edit Feature, and click the button with arrows to the left of the plane selection. This should yield a cube with a cut.

Repeat this step with the other two planes.

![Alt text](https://cdn.thingiverse.com/assets/62/5b/11/9c/b3/MakerEd_18_cut.png)
The cube with three planes cut. From this point on, unnecessary lines and planes will be hidden for ease of viewing.

## Step 4: Adding the symmetry

Now that we have cut the cube, we can now use symmetry operations (rotations, in this case) to make more cuts into the cube. The tetartohedral class has only two-fold and three fold axes of symmetry, so we are limited to these rotations.

Click Insert>Features>Move/Copy... and select the cut solid. Make two copies and rotate 120 degrees on the three-fold. The outcome will look strange, but that's normal.

![Alt text](https://cdn.thingiverse.com/assets/d6/1d/a3/12/89/MakerEd_19_cut_rotations.png)
Rotating the cube twice. The yellow areas denote overlap.

![Alt text](https://cdn.thingiverse.com/assets/f7/d1/da/3c/54/MakerEd_20_threefold_rotation_finished.png)
After accepting the rotation. Looks strange but that's right.

Using the Intersect function on the Features tab, click all three solids and press Intersect. A list of seven intersection areas should appear. Select the last region and press Invert Selection (or, select all of the regions but the last region). Make sure the Merge Faces option is checked.

![Alt text](https://cdn.thingiverse.com/assets/e8/bf/de/cf/8b/MakerEd_21_Intersect.png)
Intersecting the three bodies.

Using the Move/Copy function, rotate the solid on the origin 180 degrees on the x-axis (one copy). Then intersect, taking only the inside region (which is almost always the last region).

Make another rotation about the origin, this time 180 degrees on the *z-axis*. Intersect and take the inside region. You're done!

![Alt text](https://cdn.thingiverse.com/assets/b1/5b/a6/74/89/MakerEd_22_two-fold.png)
Rotating 180 degrees (two-fold axis of symmetry). Make sure to do this twice, once on the x-axis, and once on the z-axis.

![Alt text](https://cdn.thingiverse.com/assets/6d/2d/d5/65/3d/MakerEd_23_done.png)
Done!

## Duration

This project should take less than two hours to complete step-by-step, but could take more if the student is attempting to cut different planes/model a different class.

## Preparation

Students should know how to sketch points, lines and make planes. An understanding of bodies and features, as well as inclusion/exclusion principle will help the student understand how to use the Intersection tool. Screenshots have been added to show the student where the inputted numbers should go.

## Extension: Exploring the combinations

Now that you've finished this solid, see what happens if you change the orientations of the planes. 
* Change the coordinates of one of the normal 'vectors' to the planes. What is the difference between a plane in the form of {hk0} compared to {hkl}? 
* What happens if you change how deep you cut (do this by editing a plane and selecting a different point for the second reference)? 
* Read on to learn about the other crystal classes, then try to make models in each class!

## Extension: The Crystal Classes

As mentioned in the previous section, the cubic system is defined by having 4 three-fold axes. This means that there are a couple of possible symmetry combinations. Don't worry too much about the notation. It basically denotes what kind of symmetry exists (2,3,4) and whether there's a mirror plane perpendicular to those axes of symmetry. NOTE: '-' denotes rotoinversion.

1. Hexoctahedral Class (4/m -3 2/m)

This class has four-fold, three-fold, two-fold symmetry and mirror planes perpendicular to the four-fold and two-fold. Sound similar? The cube is included in this class!

![Alt text](https://cdn.thingiverse.com/assets/4f/5d/8b/23/df/MakerEd_10_Hexoctahedral.png)
Tetrahexahedron {104} Tetrahexahedron {102} Hexoctahedron {214}. Note that this example and this Thing were cut from the same planes but with different symmetry.

2. Hextetrahedral Class (-4 3 m)
This class has four-folds, but they are disguised as rotoinverted two-folds. This means that if the solid is rotated 90 degrees on the two-fold axis, then you look from the other side of the axis, it will look the same. The tetrahedron is a member of this class.

![Alt text](https://cdn.thingiverse.com/assets/af/9d/de/fe/3f/MakerEd_11_Hextetrahedral.png)
Tetrahexahedron {104} Tetrahexahedron {102} Hextetrahedron {214}

3. Gyroidal Class (4 3 2)

This class has everything but mirror planes. It looks like a gyroid-like spinning thing.

![Alt text](https://cdn.thingiverse.com/assets/6b/c2/d6/e6/2f/MakerEd_12_gyroidal.png)
Tetrahexahedron {104} Tetrahexahedron {102} Gyroid {214}

4. Diploidal Class (2/m -3)

A little different from the gyroidal class in that it has mirror planes and no four-folds.

![Alt text](https://cdn.thingiverse.com/assets/07/8c/fa/9a/fb/MakerEd_13_diploidal.png)
Pyritohedron {104} Pyritohedron {102} Diploid {214}

5. Tetartohedral Class (2 3)

This class has only two-folds and three-folds. You just made this model!

![Alt text](https://cdn.thingiverse.com/assets/6f/01/60/56/b9/MakerEd_14_tetartohedral.png)
Pyritohedron {104} Pyritohedron {102} Tetartohedron {214}

## References

The Primer and Extension sections described in this MakerEd Project are good resources for understanding the math behind the project. For more information, check out the links below:

[Wikipedia: Miller Index](https://en.wikipedia.org/wiki/Miller_index)
[Wikipedia: Crystal System](https://en.wikipedia.org/wiki/Crystal_system)
[Wikipedia: Cubic Crystal System](https://en.wikipedia.org/wiki/Cubic_crystal_system)

Ever wonder why I only explained two-fold, three-fold, four-fold and six-fold axes of symmetry? This is because crystal lattices are repeating units; that is, they must tessellate in 3D space, so other types of radial symmetry (e.g. five-folds and eight-folds) are not possible. Check out more at [Wikipedia: Crystallographic Restriction Theorem](https://en.wikipedia.org/wiki/Crystallographic_restriction_theorem).

Why are there names next to each Miller Index in each model? This is called a *form*, or a group of symmetry-linked faces. If you think about it, we used symmetry via two-fold and three-fold rotations to reproduce cuts in the model. If we were to cut only one plane and use symmetry operations, we would get a model with a *closed form*. Cutting the cube with only {102} would yield a *pyritohedron*, hence the naming convention.


## Rubric & Assessment

By the end of this project, a student meets the expectations by making a working model of the project. Students pass expectations by making other crystallographic models outlined in the Extension section.

## Handouts

A rubric is attached. The SolidWorks file can also be used as a step-by-step reference.